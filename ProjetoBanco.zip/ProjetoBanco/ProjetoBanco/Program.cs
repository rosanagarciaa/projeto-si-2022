﻿using System;
using ProjetoBanco.Classes;

namespace ProjetoBanco
{
    class program
    {
        static void Main()
        {

            var cliente = Cliente.CreateCliente("Rosana", "Rua Padre Duarte 222", 16997228596, "452.652.965.87", new DateTime(1999, 3, 22));

            Console.WriteLine(cliente.ToString());

        }
    }
}
